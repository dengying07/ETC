#!/usr/bin/perl -w
use strict;

my $max = <DATA>;
do {print "$max\n";} while --$max >=0;

1;
__END__
10