#!/usr/bin/perl -w
use strict;

print "Hello world!\n";

1;
