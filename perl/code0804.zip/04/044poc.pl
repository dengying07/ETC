warn;	# Perl will warn at 044poc.pl line 1
# line 200 "bzzzt"
# the previous '#' must on the first column
warn;	# Perl will warn at bzzzt line 201, instead of 044poc.pl line 4
die;	# Perl will die at bzzzt line 202
